#pragma once

#ifdef _WIN32
#define PRIx64 "llx"
#define PRIu64 "llu"
#endif