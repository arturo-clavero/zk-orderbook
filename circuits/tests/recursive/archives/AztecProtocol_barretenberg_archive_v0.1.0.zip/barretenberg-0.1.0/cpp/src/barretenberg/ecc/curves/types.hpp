#pragma once

namespace proof_system {
enum CurveType { BN254, SECP256K1, SECP256R1, GRUMPKIN };
}
