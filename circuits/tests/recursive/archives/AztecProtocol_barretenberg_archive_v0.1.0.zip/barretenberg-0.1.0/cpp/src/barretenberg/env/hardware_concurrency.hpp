#pragma once
#include <cstdint>

extern "C" uint32_t env_hardware_concurrency();