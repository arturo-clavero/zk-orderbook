#include <cstdint>
#include <barretenberg/common/serialize.hpp>
#include "barretenberg/common/wasm_export.hpp"

WASM_EXPORT void examples_simple_create_and_verify_proof(bool* valid);
