#pragma once
#include "account_note.hpp"
#include "compute_account_alias_hash_nullifier.hpp"
#include "compute_account_public_key_nullifier.hpp"