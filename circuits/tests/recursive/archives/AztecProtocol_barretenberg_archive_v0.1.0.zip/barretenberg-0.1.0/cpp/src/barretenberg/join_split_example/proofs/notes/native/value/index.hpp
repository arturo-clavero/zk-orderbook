#pragma once
#include "value_note.hpp"
#include "compute_nullifier.hpp"